package com.booktracker.book_catalog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookCatalogApplicationTests {

	@Test
	void contextLoads() {
	}

}
